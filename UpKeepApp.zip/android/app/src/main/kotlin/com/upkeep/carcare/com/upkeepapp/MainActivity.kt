package com.upkeep.carcare.com.upkeepapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
